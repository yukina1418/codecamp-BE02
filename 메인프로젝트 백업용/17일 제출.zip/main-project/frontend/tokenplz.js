async function api() {
  const getToken = await axios({
    url: "https://api.iamport.kr/users/getToken",
    method: "post", // POST method
    headers: { "Content-Type": "application/json" }, // "Content-Type": "application/json"
    data: {
      imp_key: "6404604046350897", // REST API키
      imp_secret:
        "d985bccc19517f42ca85d0ab922976b66b8405064561b2f5c575343d1864d967ce159d705b3b878d", // REST API Secret
    },
  });
  console.log(getToken.data.response);
}
