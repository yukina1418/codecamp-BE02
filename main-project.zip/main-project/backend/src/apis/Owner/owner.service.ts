import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Owner } from './models/entities/owner.entity';

@Injectable()
export class OwnerService {
  constructor(
    @InjectRepository(Owner)
    private readonly ownerRepository: Repository<Owner>,
  ) {}

  async findOne({ OnwerId }) {
    return await this.ownerRepository.findOne({ where: { owner_id: OnwerId } }); // 쿼리문 조건문
  }
  async findAll() {
    return await this.ownerRepository.find({ withDeleted: true });
  }
  async create({ createOwnerInput }) {
    const result = await this.ownerRepository.save({
      ...createOwnerInput,
    });

    return result;
  }

  async update({ OnwerId, updateOwnerInput }) {
    const owner = await this.ownerRepository.findOne({
      where: { owner_id: OnwerId },
    });

    const newProduct = {
      ...owner,
      ...updateOwnerInput,
    };
    return await this.ownerRepository.save(newProduct);
  }

  async delete({ OnwerId }) {
    const result = await this.ownerRepository.softDelete({ owner_id: OnwerId }); // 다양한 조건으로 삭제 가능
    return result.affected ? true : false;
  }

  async restore({ OnwerId }) {
    const result = await this.ownerRepository.restore({ owner_id: OnwerId }); // 다양한 조건으로 삭제 가능
    return result.affected ? true : false;
  }
}
