import { Field, Int, ObjectType } from '@nestjs/graphql';
import {
  Column,
  DeleteDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@ObjectType()
@Entity()
export class Owner {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  owner_id: string;

  @Column()
  @Field(() => String)
  owner_login_id: string;

  @Column()
  @Field(() => String)
  password: string;

  @Column()
  @Field(() => String)
  owner_name: string;

  @Column()
  @Field(() => String)
  owner_rrn: string;

  @Column()
  @Field(() => Int)
  owner_phone: number;

  @Column()
  @Field(() => String)
  owner_email: string;

  @Column()
  @Field(() => String)
  owner_nickname: string;

  @DeleteDateColumn()
  deleteAt: Date;

  @Column({
    nullable: false,
    default: () => 'CURRENT_TIMESTAMP',
    type: 'timestamp',
  })
  @Field(() => Date)
  Owner_since: Date;
}
