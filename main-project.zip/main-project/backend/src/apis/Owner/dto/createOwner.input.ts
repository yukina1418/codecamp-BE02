import { Field, InputType, Int } from '@nestjs/graphql';

@InputType()
export class CreateOwnerInput {
  @Field(() => String)
  owner_login_id: string;

  @Field(() => String)
  password: string;

  @Field(() => String)
  owner_name: string;

  @Field(() => String)
  owner_rrn: string;

  @Field(() => Int)
  owner_phone: number;

  @Field(() => String)
  owner_email: string;

  @Field(() => String)
  owner_nickname: string;
}
