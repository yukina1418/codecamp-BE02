import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { CreateOwnerInput } from './dto/createOwner.input';
import { UpdateOwnerInput } from './dto/updateOwner.input';
import { Owner } from './models/entities/owner.entity';
import { OwnerService } from './owner.service';

@Resolver()
export class OwnerResolver {
  constructor(private readonly ownerService: OwnerService) {} // 이렇게 쓰면 서비스 ts에 있는 클래스를 가져다가 쓸 수 있음

  @Query(() => Owner)
  fetchOwner(
    //
    @Args('OnwerId') OnwerId: string,
  ) {
    return this.ownerService.findOne({ OnwerId });
  }

  @Query(() => [Owner])
  fetchOwners() {
    return this.ownerService.findAll();
  }

  @Mutation(() => Owner)
  createOwner(
    @Args('createOwnerInput') createOwnerInput: CreateOwnerInput, // args == 주는쪽
  ) {
    return this.ownerService.create({ createOwnerInput });
  }

  @Mutation(() => Owner)
  async updateOwner(
    @Args('OnwerId') OnwerId: string,
    @Args('updateOwnerInput') updateOwnerInput: UpdateOwnerInput,
  ) {
    return await this.ownerService.update({ OnwerId, updateOwnerInput });
  }

  @Mutation(() => Boolean)
  deleteOwner(
    @Args('OnwerId') OnwerId: string, //
  ) {
    return this.ownerService.delete({ OnwerId });
  }

  @Mutation(() => Boolean)
  restoreOwner(
    @Args('OnwerId') OnwerId: string, //
  ) {
    return this.ownerService.restore({ OnwerId });
  }
}
