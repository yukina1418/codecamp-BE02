//auth.controller.ts
import { Controller, Get, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Request, Response } from 'express';
import { User } from '../User/models/entities/user.entity';
import { UserService } from '../User/user.service';
import { AuthService } from './auth.service';

interface IOAuthUser {
  user: Pick<User, 'user_email' | 'password' | 'user_name'>;
}

@Controller('/')
export class AuthController {
  constructor(
    private readonly userService: UserService,
    private readonly authService: AuthService,
  ) {}

  @Get('/login/google')
  @UseGuards(AuthGuard('google'))
  async loginGoogle(
    @Req() req: Request & IOAuthUser, //
    @Res() res: Response,
  ) {
    // 가입확인
    console.log(req.user);

    let user = await this.userService.findOne({
      user_email: req.user.user_email,
    });

    // 회원가입
    if (!user) {
      const { password, ...rest } = req.user;
      const createUserInput = { ...rest, password };
      user = await this.userService.create({ createUserInput });
    }

    // 로그인
    this.authService.setRefreshToken({ user, res });
    res.redirect(
      'http://localhost:5500/main-project/frontend/login/index.html',
    );
  }
}
