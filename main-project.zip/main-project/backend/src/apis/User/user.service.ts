import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from './models/entities/user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly UserRepository: Repository<User>,
  ) {}

  async findOne({ user_email }) {
    return await this.UserRepository.findOne({ where: { user_email } }); // 쿼리문 조건문
  }
  async findAll() {
    return await this.UserRepository.find({ withDeleted: true });
  }
  async create({ createUserInput }) {
    // 중복 검출 단 //
    const user = await this.UserRepository.findOne({
      where: { user_phone: createUserInput.user_phone },
    });
    const overlap = await this.UserRepository.findOne({
      where: { user_email: createUserInput.user_email },
    });

    // if (user)
    //   throw new ConflictException(
    //     '동일한 핸드폰 번호로 계정이 등록되어있습니다.',
    //   );

    if (overlap)
      throw new ConflictException('동일한 아이디로 생성된 계정이 존재합니다.');
    // 중복 검출 단 //

    //
    // ~~비밀번호 암호화~~

    createUserInput.password = await bcrypt.hash(createUserInput.password, 10);
    // ~~비밀번호 암호화~~
    const result = await this.UserRepository.save({
      ...createUserInput,
    });

    return result;
  }

  async update({ user_email, updateUserInput }) {
    const user = await this.UserRepository.findOne({ where: { user_email } });

    const newProduct = {
      ...user,
      ...updateUserInput,
    };
    return await this.UserRepository.save(newProduct);
  }

  async delete({ user_email }) {
    const result = await this.UserRepository.softDelete({ user_email }); // 다양한 조건으로 삭제 가능
    return result.affected ? true : false;
  }

  async restore({ user_email }) {
    const result = await this.UserRepository.restore({ user_email }); // 다양한 조건으로 삭제 가능
    return result.affected ? true : false;
  }

  async loginUpdate({ user_email, password }) {
    const user = await this.UserRepository.findOne({ where: { user_email } });
    user.password = await bcrypt.hash(password, 10);

    const newUserData = {
      ...user,
    };

    return await this.UserRepository.save(newUserData);
  }
}
