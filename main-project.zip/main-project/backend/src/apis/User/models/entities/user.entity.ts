import { Field, ObjectType } from '@nestjs/graphql';
import { User_Rank } from 'src/apis/UserRank/models/entities/user_rank.entity';
import {
  Column,
  DeleteDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@ObjectType()
@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  user_id: string;

  @Column({ unique: true })
  @Field(() => String)
  user_email: string;

  @Column()
  //  @Field(() => String)
  password: string;

  @Column({ nullable: true })
  @Field(() => String)
  user_name: string;

  @Column({ nullable: true })
  @Field(() => String)
  user_rrn: string;

  @Column({ nullable: true })
  @Field(() => String)
  user_phone: string;

  @Column({ nullable: true })
  @Field(() => String)
  user_nickname: string;

  @Column({ nullable: true })
  @Field(() => String)
  address: string;

  @Column({
    nullable: false,
    default: () => 'CURRENT_TIMESTAMP',
    type: 'timestamp',
  })
  @Field(() => Date)
  member_since: Date;

  @ManyToOne(() => User_Rank)
  user_Rank: User_Rank;

  @DeleteDateColumn()
  deleteAt: Date;
}
