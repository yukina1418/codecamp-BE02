import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Owner } from '../Owner/models/entities/owner.entity';
import { Subscription } from './models/entities/subscription.entity';
import { SubscriptionResolver } from './subscription.resolver';
import { SubscriptionService } from './subscription.service';

@Module({
  imports: [TypeOrmModule.forFeature([Subscription, Owner])],
  providers: [
    SubscriptionResolver, //
    SubscriptionService,
  ],
})
export class SubscriptionModule {}
